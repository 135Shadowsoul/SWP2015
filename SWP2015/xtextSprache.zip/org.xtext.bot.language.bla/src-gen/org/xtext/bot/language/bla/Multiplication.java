/**
 */
package org.xtext.bot.language.bla;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Multiplication</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.bot.language.bla.BlaPackage#getMultiplication()
 * @model
 * @generated
 */
public interface Multiplication extends MathematicalInstructions
{
} // Multiplication
