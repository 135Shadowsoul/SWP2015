/**
 */
package org.xtext.bot.language.bla.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.xtext.bot.language.bla.BlaPackage;
import org.xtext.bot.language.bla.MathValue;
import org.xtext.bot.language.bla.Var;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Math Value</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.xtext.bot.language.bla.impl.MathValueImpl#getVariableMathFeature <em>Variable Math Feature</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MathValueImpl extends MinimalEObjectImpl.Container implements MathValue
{
  /**
   * The cached value of the '{@link #getVariableMathFeature() <em>Variable Math Feature</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getVariableMathFeature()
   * @generated
   * @ordered
   */
  protected Var variableMathFeature;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected MathValueImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return BlaPackage.Literals.MATH_VALUE;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Var getVariableMathFeature()
  {
    if (variableMathFeature != null && variableMathFeature.eIsProxy())
    {
      InternalEObject oldVariableMathFeature = (InternalEObject)variableMathFeature;
      variableMathFeature = (Var)eResolveProxy(oldVariableMathFeature);
      if (variableMathFeature != oldVariableMathFeature)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, BlaPackage.MATH_VALUE__VARIABLE_MATH_FEATURE, oldVariableMathFeature, variableMathFeature));
      }
    }
    return variableMathFeature;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Var basicGetVariableMathFeature()
  {
    return variableMathFeature;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setVariableMathFeature(Var newVariableMathFeature)
  {
    Var oldVariableMathFeature = variableMathFeature;
    variableMathFeature = newVariableMathFeature;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, BlaPackage.MATH_VALUE__VARIABLE_MATH_FEATURE, oldVariableMathFeature, variableMathFeature));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case BlaPackage.MATH_VALUE__VARIABLE_MATH_FEATURE:
        if (resolve) return getVariableMathFeature();
        return basicGetVariableMathFeature();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case BlaPackage.MATH_VALUE__VARIABLE_MATH_FEATURE:
        setVariableMathFeature((Var)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case BlaPackage.MATH_VALUE__VARIABLE_MATH_FEATURE:
        setVariableMathFeature((Var)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case BlaPackage.MATH_VALUE__VARIABLE_MATH_FEATURE:
        return variableMathFeature != null;
    }
    return super.eIsSet(featureID);
  }

} //MathValueImpl
