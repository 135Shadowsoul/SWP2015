/**
 */
package org.xtext.bot.language.bla.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.xtext.bot.language.bla.BlaPackage;
import org.xtext.bot.language.bla.MathValue;
import org.xtext.bot.language.bla.MathematicalInstructions;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Mathematical Instructions</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.xtext.bot.language.bla.impl.MathematicalInstructionsImpl#getValueLeft <em>Value Left</em>}</li>
 *   <li>{@link org.xtext.bot.language.bla.impl.MathematicalInstructionsImpl#getValueRight <em>Value Right</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MathematicalInstructionsImpl extends CompareFeatureImpl implements MathematicalInstructions
{
  /**
   * The cached value of the '{@link #getValueLeft() <em>Value Left</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getValueLeft()
   * @generated
   * @ordered
   */
  protected MathValue valueLeft;

  /**
   * The cached value of the '{@link #getValueRight() <em>Value Right</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getValueRight()
   * @generated
   * @ordered
   */
  protected MathValue valueRight;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected MathematicalInstructionsImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return BlaPackage.Literals.MATHEMATICAL_INSTRUCTIONS;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MathValue getValueLeft()
  {
    return valueLeft;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetValueLeft(MathValue newValueLeft, NotificationChain msgs)
  {
    MathValue oldValueLeft = valueLeft;
    valueLeft = newValueLeft;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, BlaPackage.MATHEMATICAL_INSTRUCTIONS__VALUE_LEFT, oldValueLeft, newValueLeft);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setValueLeft(MathValue newValueLeft)
  {
    if (newValueLeft != valueLeft)
    {
      NotificationChain msgs = null;
      if (valueLeft != null)
        msgs = ((InternalEObject)valueLeft).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - BlaPackage.MATHEMATICAL_INSTRUCTIONS__VALUE_LEFT, null, msgs);
      if (newValueLeft != null)
        msgs = ((InternalEObject)newValueLeft).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - BlaPackage.MATHEMATICAL_INSTRUCTIONS__VALUE_LEFT, null, msgs);
      msgs = basicSetValueLeft(newValueLeft, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, BlaPackage.MATHEMATICAL_INSTRUCTIONS__VALUE_LEFT, newValueLeft, newValueLeft));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MathValue getValueRight()
  {
    return valueRight;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetValueRight(MathValue newValueRight, NotificationChain msgs)
  {
    MathValue oldValueRight = valueRight;
    valueRight = newValueRight;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, BlaPackage.MATHEMATICAL_INSTRUCTIONS__VALUE_RIGHT, oldValueRight, newValueRight);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setValueRight(MathValue newValueRight)
  {
    if (newValueRight != valueRight)
    {
      NotificationChain msgs = null;
      if (valueRight != null)
        msgs = ((InternalEObject)valueRight).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - BlaPackage.MATHEMATICAL_INSTRUCTIONS__VALUE_RIGHT, null, msgs);
      if (newValueRight != null)
        msgs = ((InternalEObject)newValueRight).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - BlaPackage.MATHEMATICAL_INSTRUCTIONS__VALUE_RIGHT, null, msgs);
      msgs = basicSetValueRight(newValueRight, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, BlaPackage.MATHEMATICAL_INSTRUCTIONS__VALUE_RIGHT, newValueRight, newValueRight));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case BlaPackage.MATHEMATICAL_INSTRUCTIONS__VALUE_LEFT:
        return basicSetValueLeft(null, msgs);
      case BlaPackage.MATHEMATICAL_INSTRUCTIONS__VALUE_RIGHT:
        return basicSetValueRight(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case BlaPackage.MATHEMATICAL_INSTRUCTIONS__VALUE_LEFT:
        return getValueLeft();
      case BlaPackage.MATHEMATICAL_INSTRUCTIONS__VALUE_RIGHT:
        return getValueRight();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case BlaPackage.MATHEMATICAL_INSTRUCTIONS__VALUE_LEFT:
        setValueLeft((MathValue)newValue);
        return;
      case BlaPackage.MATHEMATICAL_INSTRUCTIONS__VALUE_RIGHT:
        setValueRight((MathValue)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case BlaPackage.MATHEMATICAL_INSTRUCTIONS__VALUE_LEFT:
        setValueLeft((MathValue)null);
        return;
      case BlaPackage.MATHEMATICAL_INSTRUCTIONS__VALUE_RIGHT:
        setValueRight((MathValue)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case BlaPackage.MATHEMATICAL_INSTRUCTIONS__VALUE_LEFT:
        return valueLeft != null;
      case BlaPackage.MATHEMATICAL_INSTRUCTIONS__VALUE_RIGHT:
        return valueRight != null;
    }
    return super.eIsSet(featureID);
  }

} //MathematicalInstructionsImpl
