/**
 */
package org.xtext.bot.language.bla;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Bot Language</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.xtext.bot.language.bla.BotLanguage#getStart <em>Start</em>}</li>
 *   <li>{@link org.xtext.bot.language.bla.BotLanguage#getAddress <em>Address</em>}</li>
 *   <li>{@link org.xtext.bot.language.bla.BotLanguage#getInstructions <em>Instructions</em>}</li>
 * </ul>
 *
 * @see org.xtext.bot.language.bla.BlaPackage#getBotLanguage()
 * @model
 * @generated
 */
public interface BotLanguage extends EObject
{
  /**
   * Returns the value of the '<em><b>Start</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Start</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Start</em>' containment reference.
   * @see #setStart(Start)
   * @see org.xtext.bot.language.bla.BlaPackage#getBotLanguage_Start()
   * @model containment="true"
   * @generated
   */
  Start getStart();

  /**
   * Sets the value of the '{@link org.xtext.bot.language.bla.BotLanguage#getStart <em>Start</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Start</em>' containment reference.
   * @see #getStart()
   * @generated
   */
  void setStart(Start value);

  /**
   * Returns the value of the '<em><b>Address</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Address</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Address</em>' containment reference.
   * @see #setAddress(Address)
   * @see org.xtext.bot.language.bla.BlaPackage#getBotLanguage_Address()
   * @model containment="true"
   * @generated
   */
  Address getAddress();

  /**
   * Sets the value of the '{@link org.xtext.bot.language.bla.BotLanguage#getAddress <em>Address</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Address</em>' containment reference.
   * @see #getAddress()
   * @generated
   */
  void setAddress(Address value);

  /**
   * Returns the value of the '<em><b>Instructions</b></em>' containment reference list.
   * The list contents are of type {@link org.xtext.bot.language.bla.Instruction}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Instructions</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Instructions</em>' containment reference list.
   * @see org.xtext.bot.language.bla.BlaPackage#getBotLanguage_Instructions()
   * @model containment="true"
   * @generated
   */
  EList<Instruction> getInstructions();

} // BotLanguage
