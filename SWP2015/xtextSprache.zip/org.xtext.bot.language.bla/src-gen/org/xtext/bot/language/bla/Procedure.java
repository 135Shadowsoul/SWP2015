/**
 */
package org.xtext.bot.language.bla;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Procedure</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.bot.language.bla.BlaPackage#getProcedure()
 * @model
 * @generated
 */
public interface Procedure extends Instruction
{
} // Procedure
