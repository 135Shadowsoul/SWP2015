/**
 */
package org.xtext.bot.language.bla;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Stop</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.bot.language.bla.BlaPackage#getStop()
 * @model
 * @generated
 */
public interface Stop extends Instruction, Procedure
{
} // Stop
