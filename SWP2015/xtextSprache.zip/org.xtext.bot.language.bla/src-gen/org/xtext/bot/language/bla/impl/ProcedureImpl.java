/**
 */
package org.xtext.bot.language.bla.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.bot.language.bla.BlaPackage;
import org.xtext.bot.language.bla.Procedure;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Procedure</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class ProcedureImpl extends InstructionImpl implements Procedure
{
  /**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  protected ProcedureImpl()
  {
		super();
	}

  /**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  @Override
  protected EClass eStaticClass()
  {
		return BlaPackage.Literals.PROCEDURE;
	}

} //ProcedureImpl
