/**
 */
package org.xtext.bot.language.bla;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Addition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.bot.language.bla.BlaPackage#getAddition()
 * @model
 * @generated
 */
public interface Addition extends MathematicalInstructions
{
} // Addition
