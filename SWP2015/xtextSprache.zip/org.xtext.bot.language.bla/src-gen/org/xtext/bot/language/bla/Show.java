/**
 */
package org.xtext.bot.language.bla;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Show</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.xtext.bot.language.bla.Show#getName <em>Name</em>}</li>
 *   <li>{@link org.xtext.bot.language.bla.Show#getValue <em>Value</em>}</li>
 * </ul>
 *
 * @see org.xtext.bot.language.bla.BlaPackage#getShow()
 * @model
 * @generated
 */
public interface Show extends Procedure
{
  /**
   * Returns the value of the '<em><b>Name</b></em>' attribute list.
   * The list contents are of type {@link java.lang.String}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name</em>' attribute list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name</em>' attribute list.
   * @see org.xtext.bot.language.bla.BlaPackage#getShow_Name()
   * @model unique="false"
   * @generated
   */
  EList<String> getName();

  /**
   * Returns the value of the '<em><b>Value</b></em>' attribute list.
   * The list contents are of type {@link java.lang.String}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Value</em>' attribute list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Value</em>' attribute list.
   * @see org.xtext.bot.language.bla.BlaPackage#getShow_Value()
   * @model unique="false"
   * @generated
   */
  EList<String> getValue();

} // Show
