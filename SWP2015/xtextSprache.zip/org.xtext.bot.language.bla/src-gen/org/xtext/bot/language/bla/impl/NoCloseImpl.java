/**
 */
package org.xtext.bot.language.bla.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.bot.language.bla.BlaPackage;
import org.xtext.bot.language.bla.NoClose;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>No Close</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class NoCloseImpl extends ProcedureImpl implements NoClose
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected NoCloseImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return BlaPackage.Literals.NO_CLOSE;
  }

} //NoCloseImpl
