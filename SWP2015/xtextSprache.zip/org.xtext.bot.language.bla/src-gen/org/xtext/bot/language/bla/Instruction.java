/**
 */
package org.xtext.bot.language.bla;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Instruction</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.bot.language.bla.BlaPackage#getInstruction()
 * @model
 * @generated
 */
public interface Instruction extends EObject
{
} // Instruction
