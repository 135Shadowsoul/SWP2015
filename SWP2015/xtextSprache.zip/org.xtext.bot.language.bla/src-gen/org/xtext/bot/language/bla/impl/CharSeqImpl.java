/**
 */
package org.xtext.bot.language.bla.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.xtext.bot.language.bla.BlaPackage;
import org.xtext.bot.language.bla.CharSeq;
import org.xtext.bot.language.bla.MathValue;
import org.xtext.bot.language.bla.Var;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Char Seq</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.xtext.bot.language.bla.impl.CharSeqImpl#getVariableMathFeature <em>Variable Math Feature</em>}</li>
 *   <li>{@link org.xtext.bot.language.bla.impl.CharSeqImpl#getValue <em>Value</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CharSeqImpl extends CompareFeatureImpl implements CharSeq
{
  /**
   * The cached value of the '{@link #getVariableMathFeature() <em>Variable Math Feature</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getVariableMathFeature()
   * @generated
   * @ordered
   */
  protected Var variableMathFeature;

  /**
   * The default value of the '{@link #getValue() <em>Value</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getValue()
   * @generated
   * @ordered
   */
  protected static final String VALUE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getValue() <em>Value</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getValue()
   * @generated
   * @ordered
   */
  protected String value = VALUE_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected CharSeqImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return BlaPackage.Literals.CHAR_SEQ;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Var getVariableMathFeature()
  {
    if (variableMathFeature != null && variableMathFeature.eIsProxy())
    {
      InternalEObject oldVariableMathFeature = (InternalEObject)variableMathFeature;
      variableMathFeature = (Var)eResolveProxy(oldVariableMathFeature);
      if (variableMathFeature != oldVariableMathFeature)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, BlaPackage.CHAR_SEQ__VARIABLE_MATH_FEATURE, oldVariableMathFeature, variableMathFeature));
      }
    }
    return variableMathFeature;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Var basicGetVariableMathFeature()
  {
    return variableMathFeature;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setVariableMathFeature(Var newVariableMathFeature)
  {
    Var oldVariableMathFeature = variableMathFeature;
    variableMathFeature = newVariableMathFeature;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, BlaPackage.CHAR_SEQ__VARIABLE_MATH_FEATURE, oldVariableMathFeature, variableMathFeature));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getValue()
  {
    return value;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setValue(String newValue)
  {
    String oldValue = value;
    value = newValue;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, BlaPackage.CHAR_SEQ__VALUE, oldValue, value));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case BlaPackage.CHAR_SEQ__VARIABLE_MATH_FEATURE:
        if (resolve) return getVariableMathFeature();
        return basicGetVariableMathFeature();
      case BlaPackage.CHAR_SEQ__VALUE:
        return getValue();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case BlaPackage.CHAR_SEQ__VARIABLE_MATH_FEATURE:
        setVariableMathFeature((Var)newValue);
        return;
      case BlaPackage.CHAR_SEQ__VALUE:
        setValue((String)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case BlaPackage.CHAR_SEQ__VARIABLE_MATH_FEATURE:
        setVariableMathFeature((Var)null);
        return;
      case BlaPackage.CHAR_SEQ__VALUE:
        setValue(VALUE_EDEFAULT);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case BlaPackage.CHAR_SEQ__VARIABLE_MATH_FEATURE:
        return variableMathFeature != null;
      case BlaPackage.CHAR_SEQ__VALUE:
        return VALUE_EDEFAULT == null ? value != null : !VALUE_EDEFAULT.equals(value);
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass)
  {
    if (baseClass == MathValue.class)
    {
      switch (derivedFeatureID)
      {
        case BlaPackage.CHAR_SEQ__VARIABLE_MATH_FEATURE: return BlaPackage.MATH_VALUE__VARIABLE_MATH_FEATURE;
        default: return -1;
      }
    }
    return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass)
  {
    if (baseClass == MathValue.class)
    {
      switch (baseFeatureID)
      {
        case BlaPackage.MATH_VALUE__VARIABLE_MATH_FEATURE: return BlaPackage.CHAR_SEQ__VARIABLE_MATH_FEATURE;
        default: return -1;
      }
    }
    return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (value: ");
    result.append(value);
    result.append(')');
    return result.toString();
  }

} //CharSeqImpl
