/**
 */
package org.xtext.bot.language.bla;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Subtraction</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.bot.language.bla.BlaPackage#getSubtraction()
 * @model
 * @generated
 */
public interface Subtraction extends MathematicalInstructions
{
} // Subtraction
