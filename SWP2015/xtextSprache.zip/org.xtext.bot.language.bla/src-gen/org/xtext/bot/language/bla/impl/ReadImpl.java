/**
 */
package org.xtext.bot.language.bla.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.xtext.bot.language.bla.BlaPackage;
import org.xtext.bot.language.bla.CompareFeature;
import org.xtext.bot.language.bla.MathValue;
import org.xtext.bot.language.bla.Read;
import org.xtext.bot.language.bla.Var;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Read</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.xtext.bot.language.bla.impl.ReadImpl#getVariableFeature <em>Variable Feature</em>}</li>
 *   <li>{@link org.xtext.bot.language.bla.impl.ReadImpl#getVariableMathFeature <em>Variable Math Feature</em>}</li>
 *   <li>{@link org.xtext.bot.language.bla.impl.ReadImpl#getName <em>Name</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ReadImpl extends ProcedureImpl implements Read
{
  /**
	 * The cached value of the '{@link #getVariableFeature() <em>Variable Feature</em>}' reference.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see #getVariableFeature()
	 * @generated
	 * @ordered
	 */
  protected Var variableFeature;

  /**
	 * The cached value of the '{@link #getVariableMathFeature() <em>Variable Math Feature</em>}' reference.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see #getVariableMathFeature()
	 * @generated
	 * @ordered
	 */
  protected Var variableMathFeature;

  /**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
  protected static final String NAME_EDEFAULT = null;

  /**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
  protected String name = NAME_EDEFAULT;

  /**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  protected ReadImpl()
  {
		super();
	}

  /**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  @Override
  protected EClass eStaticClass()
  {
		return BlaPackage.Literals.READ;
	}

  /**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public Var getVariableFeature()
  {
		if (variableFeature != null && variableFeature.eIsProxy()) {
			InternalEObject oldVariableFeature = (InternalEObject)variableFeature;
			variableFeature = (Var)eResolveProxy(oldVariableFeature);
			if (variableFeature != oldVariableFeature) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, BlaPackage.READ__VARIABLE_FEATURE, oldVariableFeature, variableFeature));
			}
		}
		return variableFeature;
	}

  /**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public Var basicGetVariableFeature()
  {
		return variableFeature;
	}

  /**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public void setVariableFeature(Var newVariableFeature)
  {
		Var oldVariableFeature = variableFeature;
		variableFeature = newVariableFeature;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, BlaPackage.READ__VARIABLE_FEATURE, oldVariableFeature, variableFeature));
	}

  /**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public Var getVariableMathFeature()
  {
		if (variableMathFeature != null && variableMathFeature.eIsProxy()) {
			InternalEObject oldVariableMathFeature = (InternalEObject)variableMathFeature;
			variableMathFeature = (Var)eResolveProxy(oldVariableMathFeature);
			if (variableMathFeature != oldVariableMathFeature) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, BlaPackage.READ__VARIABLE_MATH_FEATURE, oldVariableMathFeature, variableMathFeature));
			}
		}
		return variableMathFeature;
	}

  /**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public Var basicGetVariableMathFeature()
  {
		return variableMathFeature;
	}

  /**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public void setVariableMathFeature(Var newVariableMathFeature)
  {
		Var oldVariableMathFeature = variableMathFeature;
		variableMathFeature = newVariableMathFeature;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, BlaPackage.READ__VARIABLE_MATH_FEATURE, oldVariableMathFeature, variableMathFeature));
	}

  /**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public String getName()
  {
		return name;
	}

  /**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public void setName(String newName)
  {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, BlaPackage.READ__NAME, oldName, name));
	}

  /**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
		switch (featureID) {
			case BlaPackage.READ__VARIABLE_FEATURE:
				if (resolve) return getVariableFeature();
				return basicGetVariableFeature();
			case BlaPackage.READ__VARIABLE_MATH_FEATURE:
				if (resolve) return getVariableMathFeature();
				return basicGetVariableMathFeature();
			case BlaPackage.READ__NAME:
				return getName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

  /**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  @Override
  public void eSet(int featureID, Object newValue)
  {
		switch (featureID) {
			case BlaPackage.READ__VARIABLE_FEATURE:
				setVariableFeature((Var)newValue);
				return;
			case BlaPackage.READ__VARIABLE_MATH_FEATURE:
				setVariableMathFeature((Var)newValue);
				return;
			case BlaPackage.READ__NAME:
				setName((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

  /**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  @Override
  public void eUnset(int featureID)
  {
		switch (featureID) {
			case BlaPackage.READ__VARIABLE_FEATURE:
				setVariableFeature((Var)null);
				return;
			case BlaPackage.READ__VARIABLE_MATH_FEATURE:
				setVariableMathFeature((Var)null);
				return;
			case BlaPackage.READ__NAME:
				setName(NAME_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

  /**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  @Override
  public boolean eIsSet(int featureID)
  {
		switch (featureID) {
			case BlaPackage.READ__VARIABLE_FEATURE:
				return variableFeature != null;
			case BlaPackage.READ__VARIABLE_MATH_FEATURE:
				return variableMathFeature != null;
			case BlaPackage.READ__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		}
		return super.eIsSet(featureID);
	}

  /**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  @Override
  public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass)
  {
		if (baseClass == CompareFeature.class) {
			switch (derivedFeatureID) {
				case BlaPackage.READ__VARIABLE_FEATURE: return BlaPackage.COMPARE_FEATURE__VARIABLE_FEATURE;
				default: return -1;
			}
		}
		if (baseClass == MathValue.class) {
			switch (derivedFeatureID) {
				case BlaPackage.READ__VARIABLE_MATH_FEATURE: return BlaPackage.MATH_VALUE__VARIABLE_MATH_FEATURE;
				default: return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

  /**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  @Override
  public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass)
  {
		if (baseClass == CompareFeature.class) {
			switch (baseFeatureID) {
				case BlaPackage.COMPARE_FEATURE__VARIABLE_FEATURE: return BlaPackage.READ__VARIABLE_FEATURE;
				default: return -1;
			}
		}
		if (baseClass == MathValue.class) {
			switch (baseFeatureID) {
				case BlaPackage.MATH_VALUE__VARIABLE_MATH_FEATURE: return BlaPackage.READ__VARIABLE_MATH_FEATURE;
				default: return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

  /**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  @Override
  public String toString()
  {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //ReadImpl
