/**
 */
package org.xtext.bot.language.bla.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.bot.language.bla.Addition;
import org.xtext.bot.language.bla.BlaPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Addition</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class AdditionImpl extends MathematicalInstructionsImpl implements Addition
{
  /**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  protected AdditionImpl()
  {
		super();
	}

  /**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  @Override
  protected EClass eStaticClass()
  {
		return BlaPackage.Literals.ADDITION;
	}

} //AdditionImpl
