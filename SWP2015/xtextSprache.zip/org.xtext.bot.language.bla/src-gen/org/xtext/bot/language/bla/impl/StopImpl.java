/**
 */
package org.xtext.bot.language.bla.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.bot.language.bla.BlaPackage;
import org.xtext.bot.language.bla.Stop;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Stop</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class StopImpl extends InstructionImpl implements Stop
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected StopImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return BlaPackage.Literals.STOP;
  }

} //StopImpl
