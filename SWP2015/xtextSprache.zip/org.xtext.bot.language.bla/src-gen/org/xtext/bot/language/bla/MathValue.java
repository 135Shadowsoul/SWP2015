/**
 */
package org.xtext.bot.language.bla;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Math Value</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.bot.language.bla.MathValue#getVariableMathFeature <em>Variable Math Feature</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.bot.language.bla.BlaPackage#getMathValue()
 * @model
 * @generated
 */
public interface MathValue extends EObject
{
  /**
	 * Returns the value of the '<em><b>Variable Math Feature</b></em>' reference.
	 * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Variable Math Feature</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
	 * @return the value of the '<em>Variable Math Feature</em>' reference.
	 * @see #setVariableMathFeature(Var)
	 * @see org.xtext.bot.language.bla.BlaPackage#getMathValue_VariableMathFeature()
	 * @model
	 * @generated
	 */
  Var getVariableMathFeature();

  /**
	 * Sets the value of the '{@link org.xtext.bot.language.bla.MathValue#getVariableMathFeature <em>Variable Math Feature</em>}' reference.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Variable Math Feature</em>' reference.
	 * @see #getVariableMathFeature()
	 * @generated
	 */
  void setVariableMathFeature(Var value);

} // MathValue
